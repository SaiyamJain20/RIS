"""Review selection: never execute tests whose fixture closure starts chains."""
import json
import os
from pathlib import Path


def pytest_collection_modifyitems(config, items):
    selected, excluded = [], []
    for item in items:
        if any(n.startswith('ledger_chains') for n in item.fixturenames):
            excluded.append(item)
        else:
            selected.append(item)
    output = Path(os.environ['RIS_REVIEW_DESELECTION'])
    assert not output.exists(), 'refuse to overwrite review selection'
    output.write_text(json.dumps(dict(selected=[i.nodeid for i in selected],
                                     excludedLiveFixture=[i.nodeid for i in excluded]), indent=2) + '\n')
    items[:] = selected
    config.hook.pytest_deselected(items=excluded)
